#include <iostream>
#include <fstream>
#include <string>
#include <time.h>//srand icin
#include <Windows.h>//gotoxy icin
#include <iomanip>//setw icin
using namespace std;
char solUstKose = 201;
char duz = 205;
char sagUstKose = 187;
char solAltKose = 200;
char sagAltKose = 188;
char dikey = 186;
void ustYazdir(int elemanSayisi)
{

	cout << solUstKose;
	for (int i = 0; i < elemanSayisi; i++)
	{
		cout << duz;
	}
	cout << sagUstKose;
}
void altYazdir(int elemanSayisi)
{
	cout << solAltKose;
	for (int i = 0; i < elemanSayisi; i++)
	{
		cout << duz;
	}
	cout << sagAltKose;
}
class Ogrenci
{
protected: //Odevde kalitim kullandim. diger class lardan  erisebilmek icinse protected tanimladim
	string isim;
	string soyisim;
	int numara;
public:

	Ogrenci() { numara = 0; } //
	//dosyadan okuyacagimizda dogrudan protected degiskenlere erisemedigim icin uye fonskyon kullandim
	string _isim()
	{
		return isim;
	}
	string _soyisim()
	{
		return soyisim;
	}
	int _numara()
	{
		return numara;
	}
	
	void isimYaz(string tempIisim) //dosyaya isim yazmak icin kullandim
	{
		isim = tempIisim;
	}
	void soyisimYaz(string tempsoyisim) //dosyaya soyisim yazmak icin kullandim
	{
		soyisim = tempsoyisim;
	}
	void numaraYaz(int tempnumara) //dosyaya ogernci numarasi yazmak icin kullandim
	{
		numara = tempnumara;
	}
};
class DosyaYonetim :public Ogrenci
{
public:
	string randomIsim()
	{
		ifstream dosya;
		string dizi[4945];//t�m isimleri bir diziye atip lazim oldukca oraan cektim
		string satir;
		dosya.open("isimler.txt");
		int i = 0;
		while (getline(dosya, satir))//getline fonskonu ile tum satirlari okuttum
		{
			dizi[i] = satir;
			i++;
			if (i == 4945)
				break;
		}
		isim = dizi[rand() % 4945];
		dosya.close();
		return isim;
	}
	string randomSoyisim()
	{
		ifstream dosya;
		string satir;
		string dizi[278];// isimleri diziye atiyip lazim oldukca diziden cektim
		int i = 0;
		dosya.open("soyisimler.txt");
		while (getline(dosya, satir))
		{

			dizi[i] = satir;
			i++;
			if (i == 278)
				break;
		}
		soyisim = dizi[rand() % 278];
		dosya.close();
		return soyisim;
	}
	int randomno()
	{
		numara = rand() % 100 + 100;//numaralari rast gele attirdim
		return numara;
	}
	void ogrenciKayit(string sinifIsmi, Ogrenci ogr1)// Kayit.txt dosyasina bastircak
	{
		//sinifa dogrudan atayamadigim icin tmp olusturup yeniden bastitrdim
		ofstream dosyayaYaz("kayitlar.tmp", ios::app);//dosyadan veri kaybetmemek icin ios:: app ekledim
		ifstream dosyaOku;
		dosyaOku.open("kayitlar.txt");
		string tempSinifIsmi;
		int sinftakiEleman;//siniftaki ogrr sayisi
		while (!dosyaOku.eof())
		{
			dosyaOku >> tempSinifIsmi >> sinftakiEleman;

			if (dosyaOku.eof())
			{
				break;
			}
			dosyayaYaz << tempSinifIsmi << "\n";//dosyayi txt e  yazdirip alt satira geciom
			if (tempSinifIsmi == sinifIsmi)// gecici isim sinifa esit olursa eleman siyisini sayisi arttriip ogrenciyi dosyaya basacak
			{
				dosyayaYaz << sinftakiEleman + 1 << "\n";//kayitlarda ki ogr sayisini 1 artt�rmak icin
				dosyayaYaz << ogr1._isim() << " " << ogr1._soyisim() << " " << ogr1._numara() << "\n";
			}
			else { dosyayaYaz << sinftakiEleman << endl; }
			for (int i = 0; i < sinftakiEleman; i++)
			{
				dosyaOku >> isim >> soyisim >> numara;
				dosyayaYaz << isim << " " << soyisim << " " << numara << "\n";
			}
		}
		dosyaOku.close();
		dosyayaYaz.close();
		remove("kayitlar.txt");// kayitlar.txt yi kaldircak, rename fonsk ile de tmp dosyas�n� txt e ceviricek
		rename("kayitlar.tmp", "kayitlar.txt");

	}
	void OgrSil(string sinifismi, int No) {
		string tempsinifadi;//ogrenci sildeki gecici de�i�ken
		int tempOgrSayisi;
		string tempOgrIsmi;
		string tempOgrSoyismi;
		int tempOgrNo;

		//once diziden ��kart
		//sonra dosyadan ��kart
		ifstream dosyaOku("kayitlar.txt");
		ofstream dosyaYaz("kayitlar.tmp", ios::app);
		while (!dosyaOku.eof()) {
			dosyaOku >> tempsinifadi >> tempOgrSayisi;
			dosyaYaz << tempsinifadi << endl;
			if (dosyaOku.eof())
			{
				break;
			}
			if (tempsinifadi == sinifismi) {
				dosyaYaz << tempOgrSayisi - 1 << endl;
			}
			else {
				dosyaYaz << tempOgrSayisi << endl;
			}
			for (int i = 0; i < tempOgrSayisi; i++)
			{
				dosyaOku >> tempOgrIsmi >> tempOgrSoyismi >> tempOgrNo;
				if (tempOgrNo == No) { continue; }
				else {
					dosyaYaz << tempOgrIsmi << " " << tempOgrSoyismi << " " << tempOgrNo << endl;
				}
			}
		}
		dosyaOku.close();
		dosyaYaz.close();
		remove("kayitlar.txt");
		rename("kayitlar.tmp", "kayitlar.txt");
	}
	void sinif_sil(string ad1)
	{
		int geciciOgrenciSayisi;
		string gecicSinifIsmi;

		ofstream dosyaYaz("kayitlar.tmp", ios::app);
		ifstream dosyaOku("kayitlar.txt");

		while (!dosyaOku.eof())
		{
			dosyaOku >> gecicSinifIsmi;
			if (dosyaOku.eof())//dosya sonuna gelince ��k while dan 
				break;
			if (gecicSinifIsmi == ad1)
			{

				dosyaOku >> geciciOgrenciSayisi;
				for (int i = 0; i < geciciOgrenciSayisi; i++)
				{
					dosyaOku >> isim >> soyisim >> numara;

				}
			}

			else
			{
				dosyaOku >> geciciOgrenciSayisi;
				dosyaYaz << gecicSinifIsmi << endl << geciciOgrenciSayisi << endl;
				for (int i = 0; i < geciciOgrenciSayisi; i++)
				{
					dosyaOku >> isim >> soyisim >> numara;
					dosyaYaz << isim << " " << soyisim << " " << numara << endl;
				}
			}
		}

		dosyaOku.close();
		dosyaYaz.close();
		remove("kayitlar.txt");// kayitlar.txt yi kaldircak, rename fonk ile de tmp dosyas�n� txt e ceviricek
		rename("kayitlar.tmp", "kayitlar.txt");

	}
	void sinifKaydet(string sinifadi)//sinif ekle
	{
		ofstream dosyaOku;
		dosyaOku.open("kayitlar.txt", ios::app);
		dosyaOku << sinifadi << endl << 0 << endl;
		dosyaOku.close();
	}
	void ogrenciDegistir(int a)
	{
		int temp_ogr_sayisi;
		string temp_snf_ismi;
		ifstream dosyaOku("kayitlar.txt");
		ofstream dosyayaYaz("kayitlar.tmp");
		while (!dosyaOku.eof())
		{
			dosyaOku >> temp_snf_ismi >> temp_ogr_sayisi;
			if (dosyaOku.eof())
			{
				break;
			}
			dosyayaYaz << temp_snf_ismi << "\n" << temp_ogr_sayisi << "\n";
			for (int i = 0; i < temp_ogr_sayisi; i++)
			{
				dosyaOku >> isim >> soyisim >> numara;
				if (numara == a)
				{
					isim = randomIsim();
					soyisim = randomSoyisim();
					numara = randomno();
					dosyayaYaz << isim << " " << soyisim << " " << numara << endl;
				}
				else
				{
					dosyayaYaz << isim << " " << soyisim << " " << numara << endl;
				}
			}

		}
		dosyaOku.close();
		dosyayaYaz.close();
		remove("kayitlar.txt");
		rename("kayitlar.tmp", "kayitlar.txt");
	}

};
class Sinif : public Ogrenci
{
public:
	Ogrenci ogrsayi[100];//ogrencileri tutacak
	int ogrSayisi;
	char dizi[26] = { 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','R','S','T','U','Q','W','V','X','Y','Z' };
	string sinifIismi;
	void sinif_ismi_harfi(int sayi)
	{
		//aldi�i say� ile az harflerini birle�tircem
		sinifIismi = to_string(sayi) + dizi[rand() % 26];

	}
	void ogrenciEkle()
	{
		Ogrenci ogr;
		DosyaYonetim yardimci;
		ogr.isimYaz(yardimci.randomIsim());
		ogr.soyisimYaz(yardimci.randomSoyisim());
		ogr.numaraYaz(yardimci.randomno());
		ogrsayi[ogrSayisi] = ogr;
		ogrSayisi++;
		DosyaYonetim dy;
		dy.ogrenciKayit(sinifIismi, ogr);
	}
	void ogrenciSil(int no)
	{
		//diziden c�kk
		for (int i = 0; i < ogrSayisi - 1; i++) {

			if (ogrsayi[i]._numara() == no) {

				Ogrenci ogr = ogrsayi[i];
				ogrsayi[i] = ogrsayi[i + 1];
				ogrsayi[i + 1] = ogr;

			}

		}
		ogrSayisi--;
		DosyaYonetim nesne;
		nesne.OgrSil(sinifIismi, no);

	}
};
class Okul : public Sinif
{
public:
	Sinif _s1[50];
	int sinifSayisi;
	Okul()
	{
		ifstream dosyaOku;
		dosyaOku.open("kayitlar.txt");
		for (int i = 0; !dosyaOku.eof(); i++)
		{
			dosyaOku >> _s1[i].sinifIismi >> _s1[i].ogrSayisi;
			//once sinifa girip sonra ogrencinin ismini bastiriyoz
			for (int j = 0; j < _s1[i].ogrSayisi; j++)//j �grenci sayisi icin  i ise s�n�f sayisi icin
			{
				dosyaOku >> isim >> soyisim >> numara;

				_s1[i].ogrsayi[j].isimYaz(isim);
				_s1[i].ogrsayi[j].soyisimYaz(soyisim);
				_s1[i].ogrsayi[j].numaraYaz(numara);
			}
			sinifSayisi = i;// texteki sinif sayisi
		}
		dosyaOku.close();
	}
	void ekranaBastir()
	{
		int max_ogr = 0;
		for (int i = 0; i < sinifSayisi; i++) {
			ustYazdir(14);
		}
		cout << endl;
		for (int i = 0; i < sinifSayisi; i++) {
			cout << dikey << setw(14) << _s1[i].sinifIismi << dikey;
		}
		cout << endl;
		for (int i = 0; i < sinifSayisi; i++) {
			altYazdir(14);
		}
		cout << endl;
		for (int i = 0; i < sinifSayisi; i++) {
			if (max_ogr < _s1[i].ogrSayisi) 
				max_ogr = _s1[i].ogrSayisi;
		}
		for (int i = 0; i < max_ogr; i++)
		{
			for (int j = 0; j < sinifSayisi; j++)
			{
				if (_s1[j].ogrsayi[i]._numara() != 0) {
					ustYazdir(14);
				}
				else {cout << setw(16) << " ";}
			}
			cout << endl;
			for (int j = 0; j < sinifSayisi; j++)
			{
				if (_s1[j].ogrsayi[i]._numara() != 0) {
					cout << dikey << setw(14) << _s1[j].ogrsayi[i]._isim() << dikey;
				}
				else {cout << setw(16) << " ";}
			}
			cout << endl;
			for (int j = 0; j < sinifSayisi; j++)
			{
				if (_s1[j].ogrsayi[i]._numara() != 0) {
					cout << dikey << setw(14) << _s1[j].ogrsayi[i]._soyisim() << dikey;
				}
				else {cout << setw(16) << " ";}
			}
			cout << endl;
			for (int j = 0; j < sinifSayisi; j++)
			{
				if (_s1[j].ogrsayi[i]._numara() != 0) {
					cout << dikey << setw(14) << _s1[j].ogrsayi[i]._numara() << dikey;
				}
				else {cout << setw(16) << " ";}
			}
			cout << endl;
			for (int j = 0; j < sinifSayisi; j++)
			{
				if (_s1[j].ogrsayi[i]._numara() != 0) {
					altYazdir(14);
				}
				else {cout << setw(16) << " ";}
			}
			cout << endl;
		}
	}
};
class Program : public DosyaYonetim
{
public:
	void calistir()
	{
		while (1) {
			Okul o1;
			o1.ekranaBastir();
			cout << endl << endl;
			int x;
			cout << "1.Ogrenci ekle" << endl;
			cout << "2.Sinif ekle" << endl;
			cout << "3.Ogrenci degistir" << endl;  //kaldi
			cout << "4.Ogrenci sil" << endl;
			cout << "5.Sinif sil" << endl;//kalldi
			cout << "6.Cikis" << endl;
			cin >> x;
			switch (x)
			{
			case 1: { cout << "Hangi Sinif: ";
				string x;
				cin >> x;
				for (int i = 0; i < o1.sinifSayisi; i++) {
					if (o1._s1[i].sinifIismi == x) {
						o1._s1[i].ogrenciEkle();
					}
				}
				break;
			}
			case 2: {
				Sinif s2;
				o1.sinifSayisi++;
				s2.sinif_ismi_harfi(o1.sinifSayisi);
				DosyaYonetim dosya;
				dosya.sinifKaydet(s2.sinifIismi);
				break;
			}
			case 3: {
				cout << "No gir:";
				int x;
				cin >> x;
				DosyaYonetim d1;
				d1.ogrenciDegistir(x);
				break;
			}
			case 4: {
				int geciciNo;
				cout << "ogr no:";
				cin >> geciciNo;
				for (int i = 0; i < o1.sinifSayisi; i++)
				{
					for (int j = 0; j < o1._s1[i].ogrSayisi; j++)
					{
						if (geciciNo == o1._s1[i].ogrsayi[j]._numara())//girilen ogrenci nosu bulununca ogrenci sil fonksyonu cagrilicak
						{
							o1._s1[i].ogrenciSil(geciciNo);
						}
					}
				}
				break;
			}
			case 5: {
				cout << "Hangi Sinif: ";
				string ad1;
				cin >> ad1;
				for (int i = 0; i < o1.sinifSayisi; i++) //fordan girdigi sinifi buluyoruz
				{
					if (o1._s1[i].sinifIismi == ad1) {

						DosyaYonetim dosya;
						dosya.sinif_sil(ad1);
					}
				}
				break;
			}
			case 6: {exit(0);
			}
			}
			system("cls");
		}
	}
};
int main()
{
	srand(time(NULL));
	Program prog;
	prog.calistir();
	return 0;
}