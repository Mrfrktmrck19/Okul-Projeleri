﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NdpProject
{
    class AtikKutusu
    {
        public string isim;
        public int bosaltmaPuani;
        public int kapasite;
        public int doluHacim;
        public int dolulukOrani;
        /// <summary>
        /// Kurucu Fonksyon
        /// </summary>
        /// <param name="isim">Atık Kutusunun ismini tutar.(Organik,Kağıt,Metal,Cam)</param>
        /// <param name="bosaltmaPuani">Kutu boşaltıldığında eklenecek olan puanı tutar.</param>
        /// <param name="kapasite">Atık kutusunun hacmini tutar,progress bardaki max değerini.</param>
        /// <param name="doluHacim">Progres barın, aktif değerini(şimdiki değerini) tutmak için kullandım.</param>
        /// <param name="dolulukOrani">75% değerini hesaplamak için kullandım.</param>
        public AtikKutusu(string isim, int bosaltmaPuani, int kapasite, int doluHacim, int dolulukOrani)
        {
            this.isim = isim;
            this.bosaltmaPuani = bosaltmaPuani;
            this.kapasite = kapasite;
            this.doluHacim = doluHacim;
            this.dolulukOrani = dolulukOrani;
        }

        public int Kapasite
        {
            get 
            {
                return kapasite;
                
            }
            set 
            {
                kapasite = value; 
            }
        }

        public int DoluHacim
        {
            get 
            { 
                return doluHacim; 
            }
        }

        public int DolulukOrani
        {
            get 
            { 
                return dolulukOrani; 
            }
        }

        public int BosaltmaPuani
        {
            get
            { 
                return bosaltmaPuani; 
            }
        }

        public bool Bosalt()
        {
            //Eğer Hacim 75% ten büyükse boşaltacak..
            if (doluHacim >= kapasite * 0.75)
            {
                dolulukOrani = 0;
                doluHacim = 0;
                return true;
            }
            //...Değilse butona tıklandığında işem yapılmayacak.
            else 
            {
                return false;
            }
        }

        public bool Ekle(Atik atik)
        {
            //Atığı uygun kutuya atacak ve doluluk oranına bakacak.
            if (atik.atikGrubu == isim)
            {
                doluHacim += atik.Hacim;
                dolulukOrani = doluHacim * 100 / kapasite;
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
