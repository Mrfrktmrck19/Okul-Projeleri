﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NdpProject
{
    /// <summary>
    /// IAtik interfacesinden aldığım kalıtım ile Atik Adında bir class tanımladım.
    /// Sınıfın amacı: Cam,şişe gibi atıkların özelliklerini(çöp kutusundaki tutacağı yer)
    /// kurucuda atamak. Böylelikle interface de olmayan set yerine bir çözüm oldu.
    /// </summary>
    class Atik : IAtik
    {
        public int hacim;
        public string atikGrubu;
        public string isim;
        public System.Drawing.Image resim;
        public int Hacim
        {
            get
            {
                return hacim;
            }
        }

        public System.Drawing.Image Image
        {
            get { return resim; }
        }
        /// <summary>
        /// Kurucu Fonksyon
        /// </summary>
        /// <param name="isim">Atığın ismini tutacak(Bardak, cam şişe, salatalık, domates..).</param>
        /// <param name="atikGrubu">Atığın, oluşan 4 gruptan hangisine ait olduğu atanacak(organik,metal,cam,kağıt).</param>
        /// <param name="hacim">Progres Bar'daki value değeri.</param>
        /// <param name="resim"></param>
        public Atik(string isim, string atikGrubu, int hacim, System.Drawing.Image resim)
        {
            this.atikGrubu = atikGrubu;
            this.isim = isim;
            this.hacim = hacim;
            this.resim = resim;
        }

    }
}
