﻿/****************************************************************************************************************
 *             SAKARYA ÜNİVERSİTESİ                                                                             *
 *             BİLGİSAYAR mÜHENDİSLİĞİ                                                                          *
 *             2019/2020 NESNEYE DAYALI PROGRAMLAMA DERSİ                                                       *
 *             PROJE ÖDEVİ                                                                                      *
 *             ÖMER FARUK TOMURCUK                                                                              *
 *             1/B                                                                                              *
 *             B181210019                                                                                       *
 ***************************************************************************************************************/   
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NdpProject
{
    public partial class Form1 : Form
    {
        public int sure = 60; //Zamanı tutan değişken.
        public int puan = 0; //Puanı tutan değişken
        public Form1()
        {
            InitializeComponent();
        }

        /*Temel Mantık, bir "Atık" Class ı bir de "Atık Kutuları" classı oluşturdum.
         * Atık classı bardak cam şişe domates gibi atıkların özelliklerini tutarken Atık kutuları classı
         * atıkların ait olduğu grubun (organil,cam,metal,kağıt) özelliklerini tutacak.
         * Atıklar ve Atık Kutularına ait detaylı bilgi, kendi classlarında verilmiştir.*/

        AtikKutusu Organik = new AtikKutusu("Organik", 0, 700, 0, 0); // Oluşturulan bu referenaslara yeni oyun da değer atandı. Sebebi ise
        AtikKutusu Kagit = new AtikKutusu("Kagit", 1000, 1200, 0, 0); // Oluşturulan bu referenaslara yeni oyun da değer atandı. Sebebi ise
        AtikKutusu Cam = new AtikKutusu("Cam", 600, 2200, 0, 0);// Oluşturulan bu referenaslara yeni oyun da değer atandı. Sebebi ise
        AtikKutusu Metal = new AtikKutusu("Metal", 800, 2300, 0, 0); // Oluşturulan bu referenaslara yeni oyun da değer atandı. Sebebi ise

        Atik[] atiklar = new Atik[8];
        Random randomResim = new Random();
        int index;
        private void YeniOyun_Click(object sender, EventArgs e)
        {
            timer1.Start();//Yeni oyun butonuna basıldığında sayaç başlayacak...
            //...Atıklar referansa atılıp kurucuda değeri belirleneccek,
            atiklar[0] = new Atik("Sise", "Cam", 500, Image.FromFile("Camsise.jpg"));
            atiklar[1] = new Atik("Cam Bardak", "Cam", 250, Image.FromFile("bardak.jpg"));
            atiklar[2] = new Atik("Gazete", "Kagit", 250, Image.FromFile("gazete.jpg"));
            atiklar[3] = new Atik("Dergi", "Kagit", 200, Image.FromFile("dergi.jpg"));
            atiklar[4] = new Atik("Domates", "Organik", 150, Image.FromFile("domates.jpg"));
            atiklar[5] = new Atik("Salatalik", "Organik", 120, Image.FromFile("salatalık.jpg"));
            atiklar[6] = new Atik("Kola Kutusu", "Metal", 350, Image.FromFile("kolakutusu.jpg"));
            atiklar[7] = new Atik("Salca Kutusu", "Metal", 550, Image.FromFile("salçaKutusu.png"));

            //...random üretilen sayı, dizide indexe konulacak, böyece bir elemanı rastgele seçmiş olacağız.
            index = randomResim.Next(0, 8);
            pictureBox1.Image = atiklar[index].Image;

            //...listboxlar temizlenecek,
            ListBoxCam.Items.Clear();
            ListBoxKagit.Items.Clear();
            ListBoxMetal.Items.Clear();
            ListBoxOrganik.Items.Clear();

            //...Progres bardaki değerler temizlenecek,
            BarCam.Value = Cam.DolulukOrani;
            BarKagıt.Value = Kagit.DolulukOrani;
            BarMetal.Value = Metal.DolulukOrani;
            BarOrganikAtık.Value = Organik.DolulukOrani;

            puan = 0;
            LabelPuan.Text = puan.ToString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            /*Verilen süre arasında süre ve puanın arkaplan rengi değişecek,
             * YeniOyun butonu aktif olmayacak, ekle vve boşalt butonları aktif olacak,*/
            sure--;
            KalanZaman.Text = sure.ToString();
            if (60>sure && sure>0)
            {
                SurePaneli.BackColor = Color.Yellow;
                PuanPaneli.BackColor = Color.Yellow;
                YeniOyun.Enabled = false;
                OrganikAtıkBtn.Enabled = true;
                OrganikAtıkBosaltBtn.Enabled = true;
                KagıtBtn.Enabled = true;
                KagıtBosaltBtn.Enabled = true;
                CamBtn.Enabled = true;
                CamBosaltBtn.Enabled = true;
                MetalBtn.Enabled = true;
                MetalBosaltBtn.Enabled = true;
            }
      
            /*Sure 0 a geldiğinde timer durup arkaplan rengi eski haline gelecek,
             * süre tekrardan 60 saniye olacak,
             * Yeni oyun butonu aktif olacak, ekle ve boşalt butonları ise aktif olmayacak.*/
            if (sure == 0)
            {
                timer1.Stop();
                sure = 60;
                YeniOyun.Enabled = true;
                OrganikAtıkBtn.Enabled = false;
                OrganikAtıkBosaltBtn.Enabled = false;
                KagıtBtn.Enabled = false;
                KagıtBosaltBtn.Enabled = false;
                CamBtn.Enabled = false;
                CamBosaltBtn.Enabled = false;
                MetalBtn.Enabled = false;
                MetalBosaltBtn.Enabled = false;
            }

        }



        /****************************************************************************************************************************************/
        //ATIK KUTUSUNA EKLEME BUTONLARI
        /****************************************************************************************************************************************/

        /// <summary>
        /// Organik atıklara ait Ekle butonuna tıklandığında gelen resim ile tıklanılan butonun uyuştuğuna ve
        /// atığın kutuya sığıp sığamadığına bakıyor. İstenilen şartlar sağlanıyor ise,
        /// atık kutuya ekleniyor(progress bara verilen değer giriliyor). Kazanılan puan hesaplanıp label ile ekrana
        /// basılıyor. Sonra tekrar random sayı üretilip image dizisine koyuyor ve ekrana yen bir resim geliyor.
        /// </summary>
        
        private void OrganikAtıkBtn_Click(object sender, EventArgs e)
        {
            if (atiklar[index].atikGrubu == "Organik" && atiklar[index].Hacim + Organik.DoluHacim <= Organik.Kapasite)
            {
                Organik.Ekle(atiklar[index]);
                ListBoxOrganik.Items.Add(atiklar[index].isim + "(" + atiklar[index].Hacim + ")");
                puan += atiklar[index].Hacim;
                LabelPuan.Text = puan.ToString();
                index = randomResim.Next(0, 8);
                pictureBox1.Image = atiklar[index].Image;
                BarOrganikAtık.Value = Organik.DolulukOrani;
            }
        }

        /// <summary>
        /// Kağıt atıklara ait Ekle butonuna tıklandığında gelen resim ile tıklanılan butonun uyuştuğuna ve
        /// atığın kutuya sığıp sığamadığına bakıyor. İstenilen şartlar sağlanıyor ise,
        /// atık kutuya ekleniyor(progress bara verilen değer giriliyor). Kazanılan puan hesaplanıp label ile ekrana
        /// basılıyor. Sonra tekrar random sayı üretilip image dizisine koyuyor ve ekrana yen bir resim geliyor.
        /// </summary>

        private void KagıtBtn_Click(object sender, EventArgs e)
        {
            if (atiklar[index].atikGrubu == "Kagit" && atiklar[index].Hacim + Kagit.DoluHacim <= Kagit.Kapasite)
            {
                Kagit.Ekle(atiklar[index]);
                ListBoxKagit.Items.Add(atiklar[index].isim + "(" + atiklar[index].Hacim + ")");
                puan += atiklar[index].Hacim;
                LabelPuan.Text = puan.ToString();
                index = randomResim.Next(0, 8);
                pictureBox1.Image = atiklar[index].Image;
                BarKagıt.Value = Kagit.DolulukOrani;
            }
        }

        /// <summary>
        /// Cam atıklara ait Ekle butonuna tıklandığında gelen resim ile tıklanılan butonun uyuştuğuna ve
        /// atığın kutuya sığıp sığamadığına bakıyor. İstenilen şartlar sağlanıyor ise,
        /// atık kutuya ekleniyor(progress bara verilen değer giriliyor). Kazanılan puan hesaplanıp label ile ekrana
        /// basılıyor. Sonra tekrar random sayı üretilip image dizisine koyuyor ve ekrana yen bir resim geliyor.
        /// </summary>

        private void CamBtn_Click(object sender, EventArgs e)
        {
            if (atiklar[index].atikGrubu == "Cam" && atiklar[index].Hacim + Cam.DoluHacim <= Cam.Kapasite)
            {
                Cam.Ekle(atiklar[index]);
                ListBoxCam.Items.Add(atiklar[index].isim + "(" + atiklar[index].Hacim + ")");
                puan += atiklar[index].Hacim;
                LabelPuan.Text = puan.ToString();
                index = randomResim.Next(0, 8);
                pictureBox1.Image = atiklar[index].Image;
                BarCam.Value = Cam.DolulukOrani;
            }
        }

        /// <summary>
        /// Metal atıklara ait Ekle butonuna tıklandığında gelen resim ile tıklanılan butonun uyuştuğuna ve
        /// atığın kutuya sığıp sığamadığına bakıyor. İstenilen şartlar sağlanıyor ise,
        /// atık kutuya ekleniyor(progress bara verilen değer giriliyor). Kazanılan puan hesaplanıp label ile ekrana
        /// basılıyor. Sonra tekrar random sayı üretilip image dizisine koyuyor ve ekrana yen bir resim geliyor.
        /// </summary>

        private void MetalBtn_Click(object sender, EventArgs e)
        {
            if (atiklar[index].atikGrubu == "Metal" && atiklar[index].Hacim + Metal.DoluHacim <= Metal.Kapasite)
            {
                Metal.Ekle(atiklar[index]);
                ListBoxMetal.Items.Add(atiklar[index].isim + "(" + atiklar[index].Hacim + ")");
                puan += atiklar[index].Hacim;
                LabelPuan.Text = puan.ToString();
                index = randomResim.Next(0, 8);
                pictureBox1.Image = atiklar[index].Image;
                BarMetal.Value = Metal.DolulukOrani;
            }
        }



        /****************************************************************************************************************************************/
        //KUTUDAN BOŞALTMA BUTONLARI
        /****************************************************************************************************************************************/

        /// <summary>
        /// Organik Atıklara ait Boşalt butonuna tıklandığında fonksyon önce progress bardaki doluluk oranına bakıcak.
        /// Eğer şart sağlanıyorsa belirlenen puan eklenecek vepuan ekrana label ile çıkartılacak. Progress Bar sıfırlanıp
        /// list box da temizlenecek ve 3 saniye eklenecek.
        /// </summary>

        
        private void OrganikAtıkBosaltBtn_Click(object sender, EventArgs e)
        {
            if (Organik.DolulukOrani >= 75)
            {
                puan += Organik.BosaltmaPuani;
                LabelPuan.Text = puan.ToString();
                Organik.Bosalt();
                ListBoxOrganik.Items.Clear();
                BarOrganikAtık.Value = Organik.DolulukOrani;
                sure += 3;
            }
        }
        /// <summary>
        /// Kağıt Atıklara ait Boşalt butonuna tıklandığında fonksyon önce progress bardaki doluluk oranına bakıcak.
        /// Eğer şart sağlanıyorsa belirlenen puan eklenecek vepuan ekrana label ile çıkartılacak. Progress Bar sıfırlanıp
        /// list box da temizlenecek ve 3 saniye eklenecek.
        /// </summary>
        private void KagıtBosaltBtn_Click(object sender, EventArgs e)
        {
            if (Kagit.DolulukOrani >= 75)
            {
                puan += Kagit.BosaltmaPuani;
                LabelPuan.Text = puan.ToString();
                Kagit.Bosalt();
                ListBoxKagit.Items.Clear();
                BarKagıt.Value = Kagit.DolulukOrani;
                sure += 3;
            }
        }
        /// <summary>
        /// Cam Atıklara ait Boşalt butonuna tıklandığında fonksyon önce progress bardaki doluluk oranına bakıcak.
        /// Eğer şart sağlanıyorsa belirlenen puan eklenecek vepuan ekrana label ile çıkartılacak. Progress Bar sıfırlanıp
        /// list box da temizlenecek ve 3 saniye eklenecek.
        /// </summary>
        private void CamBosaltBtn_Click(object sender, EventArgs e)
        {
            if (Cam.DolulukOrani >= 75)
            {
                puan += Cam.BosaltmaPuani;
                LabelPuan.Text = puan.ToString();
                Cam.Bosalt();
                ListBoxCam.Items.Clear();
                BarCam.Value = Cam.DolulukOrani;
                sure += 3;
            }
        }
        /// <summary>
        /// Metal Atıklara ait Boşalt butonuna tıklandığında fonksyon önce progress bardaki doluluk oranına bakıcak.
        /// Eğer şart sağlanıyorsa belirlenen puan eklenecek vepuan ekrana label ile çıkartılacak. Progress Bar sıfırlanıp
        /// list box da temizlenecek ve 3 saniye eklenecek.
        /// </summary>

        private void MetalBosaltBtn_Click(object sender, EventArgs e)
        {
            if (Metal.DolulukOrani >= 75)
            {
                puan += Metal.BosaltmaPuani;
                LabelPuan.Text = puan.ToString();
                Metal.Bosalt();
                ListBoxMetal.Items.Clear();
                BarMetal.Value = Metal.DolulukOrani;
                sure += 3;
            }
        }
        /// <summary>
        /// Çıkış butonuna tıklandığında çıkmasını sağlayan metod.
        /// </summary>
        private void CikBtn_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
