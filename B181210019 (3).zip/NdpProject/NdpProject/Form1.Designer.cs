﻿namespace NdpProject
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.CikBtn = new System.Windows.Forms.Button();
            this.PuanPaneli = new System.Windows.Forms.Panel();
            this.LabelPuan = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.SurePaneli = new System.Windows.Forms.Panel();
            this.KalanZaman = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.YeniOyun = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.BarMetal = new System.Windows.Forms.ProgressBar();
            this.MetalBosaltBtn = new System.Windows.Forms.Button();
            this.ListBoxMetal = new System.Windows.Forms.ListBox();
            this.MetalBtn = new System.Windows.Forms.Button();
            this.BarCam = new System.Windows.Forms.ProgressBar();
            this.CamBosaltBtn = new System.Windows.Forms.Button();
            this.ListBoxCam = new System.Windows.Forms.ListBox();
            this.CamBtn = new System.Windows.Forms.Button();
            this.BarKagıt = new System.Windows.Forms.ProgressBar();
            this.BarOrganikAtık = new System.Windows.Forms.ProgressBar();
            this.KagıtBosaltBtn = new System.Windows.Forms.Button();
            this.ListBoxKagit = new System.Windows.Forms.ListBox();
            this.KagıtBtn = new System.Windows.Forms.Button();
            this.OrganikAtıkBosaltBtn = new System.Windows.Forms.Button();
            this.ListBoxOrganik = new System.Windows.Forms.ListBox();
            this.OrganikAtıkBtn = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.PuanPaneli.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SurePaneli.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 199);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(208, 172);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel2.Controls.Add(this.CikBtn);
            this.panel2.Controls.Add(this.PuanPaneli);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.SurePaneli);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.YeniOyun);
            this.panel2.Location = new System.Drawing.Point(12, 217);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(234, 399);
            this.panel2.TabIndex = 1;
            // 
            // CikBtn
            // 
            this.CikBtn.BackColor = System.Drawing.Color.Navy;
            this.CikBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.CikBtn.ForeColor = System.Drawing.Color.Snow;
            this.CikBtn.Location = new System.Drawing.Point(14, 332);
            this.CikBtn.Name = "CikBtn";
            this.CikBtn.Size = new System.Drawing.Size(208, 59);
            this.CikBtn.TabIndex = 6;
            this.CikBtn.Text = "Çıkış";
            this.CikBtn.UseVisualStyleBackColor = false;
            this.CikBtn.Click += new System.EventHandler(this.CikBtn_Click);
            // 
            // PuanPaneli
            // 
            this.PuanPaneli.Controls.Add(this.LabelPuan);
            this.PuanPaneli.Location = new System.Drawing.Point(14, 239);
            this.PuanPaneli.Name = "PuanPaneli";
            this.PuanPaneli.Size = new System.Drawing.Size(207, 71);
            this.PuanPaneli.TabIndex = 5;
            // 
            // LabelPuan
            // 
            this.LabelPuan.AutoSize = true;
            this.LabelPuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LabelPuan.Location = new System.Drawing.Point(67, 27);
            this.LabelPuan.Name = "LabelPuan";
            this.LabelPuan.Size = new System.Drawing.Size(24, 25);
            this.LabelPuan.TabIndex = 1;
            this.LabelPuan.Text = "0";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel8.Controls.Add(this.label5);
            this.panel8.Location = new System.Drawing.Point(14, 204);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(207, 44);
            this.panel8.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(67, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 25);
            this.label5.TabIndex = 0;
            this.label5.Text = "Puan";
            // 
            // SurePaneli
            // 
            this.SurePaneli.Controls.Add(this.KalanZaman);
            this.SurePaneli.Location = new System.Drawing.Point(14, 131);
            this.SurePaneli.Name = "SurePaneli";
            this.SurePaneli.Size = new System.Drawing.Size(207, 67);
            this.SurePaneli.TabIndex = 3;
            // 
            // KalanZaman
            // 
            this.KalanZaman.AutoSize = true;
            this.KalanZaman.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.KalanZaman.Location = new System.Drawing.Point(67, 27);
            this.KalanZaman.Name = "KalanZaman";
            this.KalanZaman.Size = new System.Drawing.Size(24, 25);
            this.KalanZaman.TabIndex = 1;
            this.KalanZaman.Text = "0";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel5.Controls.Add(this.label2);
            this.panel5.Location = new System.Drawing.Point(14, 96);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(207, 44);
            this.panel5.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(67, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Süre";
            // 
            // YeniOyun
            // 
            this.YeniOyun.BackColor = System.Drawing.Color.Navy;
            this.YeniOyun.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.YeniOyun.ForeColor = System.Drawing.Color.Snow;
            this.YeniOyun.Location = new System.Drawing.Point(14, 13);
            this.YeniOyun.Name = "YeniOyun";
            this.YeniOyun.Size = new System.Drawing.Size(208, 59);
            this.YeniOyun.TabIndex = 1;
            this.YeniOyun.Text = "Yeni Oyun";
            this.YeniOyun.UseVisualStyleBackColor = false;
            this.YeniOyun.Click += new System.EventHandler(this.YeniOyun_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(252, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(297, 44);
            this.panel3.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(86, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Atık Kutuları";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel4.Controls.Add(this.BarMetal);
            this.panel4.Controls.Add(this.MetalBosaltBtn);
            this.panel4.Controls.Add(this.ListBoxMetal);
            this.panel4.Controls.Add(this.MetalBtn);
            this.panel4.Controls.Add(this.BarCam);
            this.panel4.Controls.Add(this.CamBosaltBtn);
            this.panel4.Controls.Add(this.ListBoxCam);
            this.panel4.Controls.Add(this.CamBtn);
            this.panel4.Controls.Add(this.BarKagıt);
            this.panel4.Controls.Add(this.BarOrganikAtık);
            this.panel4.Controls.Add(this.KagıtBosaltBtn);
            this.panel4.Controls.Add(this.ListBoxKagit);
            this.panel4.Controls.Add(this.KagıtBtn);
            this.panel4.Controls.Add(this.OrganikAtıkBosaltBtn);
            this.panel4.Controls.Add(this.ListBoxOrganik);
            this.panel4.Controls.Add(this.OrganikAtıkBtn);
            this.panel4.Location = new System.Drawing.Point(252, 62);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(297, 554);
            this.panel4.TabIndex = 2;
            // 
            // BarMetal
            // 
            this.BarMetal.Location = new System.Drawing.Point(166, 466);
            this.BarMetal.Name = "BarMetal";
            this.BarMetal.Size = new System.Drawing.Size(106, 15);
            this.BarMetal.TabIndex = 21;
            // 
            // MetalBosaltBtn
            // 
            this.MetalBosaltBtn.Enabled = false;
            this.MetalBosaltBtn.Location = new System.Drawing.Point(166, 487);
            this.MetalBosaltBtn.Name = "MetalBosaltBtn";
            this.MetalBosaltBtn.Size = new System.Drawing.Size(107, 23);
            this.MetalBosaltBtn.TabIndex = 20;
            this.MetalBosaltBtn.Text = "Boşalt";
            this.MetalBosaltBtn.UseVisualStyleBackColor = true;
            this.MetalBosaltBtn.Click += new System.EventHandler(this.MetalBosaltBtn_Click);
            // 
            // ListBoxMetal
            // 
            this.ListBoxMetal.FormattingEnabled = true;
            this.ListBoxMetal.Location = new System.Drawing.Point(166, 301);
            this.ListBoxMetal.Name = "ListBoxMetal";
            this.ListBoxMetal.Size = new System.Drawing.Size(107, 160);
            this.ListBoxMetal.TabIndex = 19;
            // 
            // MetalBtn
            // 
            this.MetalBtn.Enabled = false;
            this.MetalBtn.Location = new System.Drawing.Point(166, 272);
            this.MetalBtn.Name = "MetalBtn";
            this.MetalBtn.Size = new System.Drawing.Size(107, 23);
            this.MetalBtn.TabIndex = 18;
            this.MetalBtn.Text = "Metal";
            this.MetalBtn.UseVisualStyleBackColor = true;
            this.MetalBtn.Click += new System.EventHandler(this.MetalBtn_Click);
            // 
            // BarCam
            // 
            this.BarCam.Location = new System.Drawing.Point(13, 466);
            this.BarCam.Name = "BarCam";
            this.BarCam.Size = new System.Drawing.Size(106, 15);
            this.BarCam.TabIndex = 17;
            // 
            // CamBosaltBtn
            // 
            this.CamBosaltBtn.Enabled = false;
            this.CamBosaltBtn.Location = new System.Drawing.Point(13, 487);
            this.CamBosaltBtn.Name = "CamBosaltBtn";
            this.CamBosaltBtn.Size = new System.Drawing.Size(107, 23);
            this.CamBosaltBtn.TabIndex = 16;
            this.CamBosaltBtn.Text = "Boşalt";
            this.CamBosaltBtn.UseVisualStyleBackColor = true;
            this.CamBosaltBtn.Click += new System.EventHandler(this.CamBosaltBtn_Click);
            // 
            // ListBoxCam
            // 
            this.ListBoxCam.FormattingEnabled = true;
            this.ListBoxCam.Location = new System.Drawing.Point(13, 301);
            this.ListBoxCam.Name = "ListBoxCam";
            this.ListBoxCam.Size = new System.Drawing.Size(107, 160);
            this.ListBoxCam.TabIndex = 15;
            // 
            // CamBtn
            // 
            this.CamBtn.Enabled = false;
            this.CamBtn.Location = new System.Drawing.Point(13, 272);
            this.CamBtn.Name = "CamBtn";
            this.CamBtn.Size = new System.Drawing.Size(107, 23);
            this.CamBtn.TabIndex = 14;
            this.CamBtn.Text = "Cam";
            this.CamBtn.UseVisualStyleBackColor = true;
            this.CamBtn.Click += new System.EventHandler(this.CamBtn_Click);
            // 
            // BarKagıt
            // 
            this.BarKagıt.Location = new System.Drawing.Point(166, 212);
            this.BarKagıt.Name = "BarKagıt";
            this.BarKagıt.Size = new System.Drawing.Size(106, 15);
            this.BarKagıt.TabIndex = 13;
            // 
            // BarOrganikAtık
            // 
            this.BarOrganikAtık.Location = new System.Drawing.Point(13, 212);
            this.BarOrganikAtık.Name = "BarOrganikAtık";
            this.BarOrganikAtık.Size = new System.Drawing.Size(106, 15);
            this.BarOrganikAtık.TabIndex = 12;
            // 
            // KagıtBosaltBtn
            // 
            this.KagıtBosaltBtn.Enabled = false;
            this.KagıtBosaltBtn.Location = new System.Drawing.Point(166, 233);
            this.KagıtBosaltBtn.Name = "KagıtBosaltBtn";
            this.KagıtBosaltBtn.Size = new System.Drawing.Size(107, 23);
            this.KagıtBosaltBtn.TabIndex = 5;
            this.KagıtBosaltBtn.Text = "Boşalt";
            this.KagıtBosaltBtn.UseVisualStyleBackColor = true;
            this.KagıtBosaltBtn.Click += new System.EventHandler(this.KagıtBosaltBtn_Click);
            // 
            // ListBoxKagit
            // 
            this.ListBoxKagit.FormattingEnabled = true;
            this.ListBoxKagit.Location = new System.Drawing.Point(166, 47);
            this.ListBoxKagit.Name = "ListBoxKagit";
            this.ListBoxKagit.Size = new System.Drawing.Size(107, 160);
            this.ListBoxKagit.TabIndex = 4;
            // 
            // KagıtBtn
            // 
            this.KagıtBtn.Enabled = false;
            this.KagıtBtn.Location = new System.Drawing.Point(166, 18);
            this.KagıtBtn.Name = "KagıtBtn";
            this.KagıtBtn.Size = new System.Drawing.Size(107, 23);
            this.KagıtBtn.TabIndex = 3;
            this.KagıtBtn.Text = "Kağıt";
            this.KagıtBtn.UseVisualStyleBackColor = true;
            this.KagıtBtn.Click += new System.EventHandler(this.KagıtBtn_Click);
            // 
            // OrganikAtıkBosaltBtn
            // 
            this.OrganikAtıkBosaltBtn.Enabled = false;
            this.OrganikAtıkBosaltBtn.Location = new System.Drawing.Point(12, 233);
            this.OrganikAtıkBosaltBtn.Name = "OrganikAtıkBosaltBtn";
            this.OrganikAtıkBosaltBtn.Size = new System.Drawing.Size(107, 23);
            this.OrganikAtıkBosaltBtn.TabIndex = 2;
            this.OrganikAtıkBosaltBtn.Text = "Boşalt";
            this.OrganikAtıkBosaltBtn.UseVisualStyleBackColor = true;
            this.OrganikAtıkBosaltBtn.Click += new System.EventHandler(this.OrganikAtıkBosaltBtn_Click);
            // 
            // ListBoxOrganik
            // 
            this.ListBoxOrganik.FormattingEnabled = true;
            this.ListBoxOrganik.Location = new System.Drawing.Point(12, 47);
            this.ListBoxOrganik.Name = "ListBoxOrganik";
            this.ListBoxOrganik.Size = new System.Drawing.Size(107, 160);
            this.ListBoxOrganik.TabIndex = 1;
            // 
            // OrganikAtıkBtn
            // 
            this.OrganikAtıkBtn.Enabled = false;
            this.OrganikAtıkBtn.Location = new System.Drawing.Point(12, 18);
            this.OrganikAtıkBtn.Name = "OrganikAtıkBtn";
            this.OrganikAtıkBtn.Size = new System.Drawing.Size(107, 23);
            this.OrganikAtıkBtn.TabIndex = 0;
            this.OrganikAtıkBtn.Text = "Organik Atık";
            this.OrganikAtıkBtn.UseVisualStyleBackColor = true;
            this.OrganikAtıkBtn.Click += new System.EventHandler(this.OrganikAtıkBtn_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(561, 627);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Atık Toplama";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.PuanPaneli.ResumeLayout(false);
            this.PuanPaneli.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.SurePaneli.ResumeLayout(false);
            this.SurePaneli.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button OrganikAtıkBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel SurePaneli;
        private System.Windows.Forms.Label KalanZaman;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button YeniOyun;
        private System.Windows.Forms.ProgressBar BarMetal;
        private System.Windows.Forms.Button MetalBosaltBtn;
        private System.Windows.Forms.ListBox ListBoxMetal;
        private System.Windows.Forms.Button MetalBtn;
        private System.Windows.Forms.ProgressBar BarCam;
        private System.Windows.Forms.Button CamBosaltBtn;
        private System.Windows.Forms.ListBox ListBoxCam;
        private System.Windows.Forms.Button CamBtn;
        private System.Windows.Forms.ProgressBar BarKagıt;
        private System.Windows.Forms.ProgressBar BarOrganikAtık;
        private System.Windows.Forms.Button KagıtBosaltBtn;
        private System.Windows.Forms.ListBox ListBoxKagit;
        private System.Windows.Forms.Button KagıtBtn;
        private System.Windows.Forms.Button OrganikAtıkBosaltBtn;
        private System.Windows.Forms.ListBox ListBoxOrganik;
        private System.Windows.Forms.Panel PuanPaneli;
        private System.Windows.Forms.Label LabelPuan;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button CikBtn;
        private System.Windows.Forms.Timer timer1;
    }
}

